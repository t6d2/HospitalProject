var Person = require(`./person`)

class Patient extends Person {

    constructor(name, surname, gender, birthDate, address, number, city, zip, imgSource) {
        super(name, surname, gender, birthDate, address, number, city, zip)
        this.imgSource = imgSource
      }
      
}

module.exports = Patient
// let patients =[]
// let patient = new Patient('Mario','Rossi', 'male','1990-02-21', 'Via Garibaldi',11,'Udine',33100, `./images/mario_rossi.jpg` )
// patients.push(patient);
// console.log(patient.gender)
