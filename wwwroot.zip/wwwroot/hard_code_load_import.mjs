import Patient from `./patient_import`

let patients = [];

let patient = new Patient('Mario','Rossi', 'male','1990-02-21', 'Via Garibaldi',11,'Udine',33100, `./images/mario_rossi.jpg` )
patients.push(patient);
console.log(patient.gender)