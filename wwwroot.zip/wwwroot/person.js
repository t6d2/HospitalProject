class Person
{
  constructor(name, surname, gender, birthDate, address, number, city, zip) {
    this.fullName =  {
        name,
        surname
    }
    this.gender = gender
    this.birthDate = birthDate
    this.addressDetails = {
        address,
        number,
        city,
        zip
    }
  }
}

module.exports = Person
